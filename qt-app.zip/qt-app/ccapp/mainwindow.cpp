#include <unistd.h>
#include <stdint.h>
#include <iostream>
#include <string>
#include <fstream>
#include <chrono>
#include <iomanip>
#include <sstream>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),
      seat_position_val(0),
      fan_speed_val(0),
      light_state_val(0),
      readThreadRunning(0),
      buttonState_current(0),
      buttonState_previous(0)

{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
    QFile file(":/resource/resource/style/style.qss");
    file.open(QFile::ReadOnly);
    QString styleSheet = QLatin1String(file.readAll());
    setStyleSheet(styleSheet);

    Builder tmpBuilder;
    client_ = tmpBuilder.GetLogicHandler();
    client_->Subscribe("VehicleSpeed", std::bind(&MainWindow::SpeedValueCallback, this, std::placeholders::_1, std::placeholders::_2));
    client_->Subscribe("DoorState", std::bind(&MainWindow::DoorStateCallback, this, std::placeholders::_1, std::placeholders::_2));
    client_->Subscribe("LightState", std::bind(&MainWindow::LightStateCallback, this, std::placeholders::_1, std::placeholders::_2));
    client_->Subscribe("FanSpeed", std::bind(&MainWindow::FanSpeedCallback, this, std::placeholders::_1, std::placeholders::_2));
    client_->Subscribe("SeatPosition", std::bind(&MainWindow::SeatPositionCallback, this, std::placeholders::_1, std::placeholders::_2));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::LOG(std::string content, QListWidget* logWidget)
{
    auto timestamp = std::chrono::system_clock::now();
    std::time_t now_tt = std::chrono::system_clock::to_time_t(timestamp);
    std::tm tm = *std::localtime(&now_tt);

    std::stringstream timestream;
    timestream << std::put_time(&tm, "%c %z");

    content = timestream.str() + " " + content;

    logWidget->addItem(content.c_str());
}

void MainWindow::SeatPositionCallback(CallbackType callback_type, uint32_t value)
{
    LOG("Seat Position:" + std::to_string(value), ui->seatLog);
}

void MainWindow::FanSpeedCallback(CallbackType callback_type, uint32_t value)
{
    LOG("Fan speed:" + std::to_string(value), ui->airLog);

}

void MainWindow::LightStateCallback(CallbackType callback_type, uint32_t value)
{
    LOG("Brightness:" + std::to_string(value), ui->lightLog);
}

void MainWindow::SpeedValueCallback(CallbackType callback_type, uint32_t value)
{
    ui->speed_value->display((int)value);
}

void MainWindow::DoorStateCallback(CallbackType callback_type, uint32_t value)
{
    ui->door_state->setNum((int)value);
}

void MainWindow::on_homeBtn_2_toggled(bool checked)
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_lightBtn_2_toggled(bool checked)
{
    ui->stackedWidget->setCurrentIndex(3);
}


void MainWindow::on_seatBtn_2_toggled(bool checked)
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MainWindow::on_airBtn_2_toggled(bool checked)
{
    ui->stackedWidget->setCurrentIndex(2);
}

// Light Control

void MainWindow::on_lightLevel_valueChanged(int value)
{
    light_state_val = value;
    client_->Feed("LightState",(uint32_t)light_state_val);
}

void MainWindow::on_onLightBtn_clicked()
{
    light_state_val = 100;
    client_->Feed("LightState",(uint32_t)light_state_val);
    LOG("set Light On", ui->lightLog);
}

void MainWindow::on_offLightBtn_clicked()
{
    light_state_val = 0;
    client_->Feed("LightState",(uint32_t)light_state_val);
    LOG("set Light OFF", ui->lightLog);
}

// Air Condition Control

void MainWindow::on_offAirBtn_clicked()
{
    fan_speed_val = 0;
    LOG("set Air Conditioner OFF", ui->airLog);
    client_->Feed("FanSpeed",(uint32_t)fan_speed_val);
}

void MainWindow::on_onAirBtn_clicked()
{
    fan_speed_val = 100;
    LOG("set Air Conditioner ON", ui->airLog);
    client_->Feed("FanSpeed",(uint32_t)fan_speed_val);
}

void MainWindow::on_airLevel1Btn_clicked()
{
    fan_speed_val = 64;
    LOG("Air Value: Level 1", ui->airLog);
    client_->Feed("FanSpeed",(uint32_t)fan_speed_val);
}
void MainWindow::on_airLevel2Btn_clicked()
{
    fan_speed_val = 128;
    LOG("Air Value: Level 2", ui->airLog);
    client_->Feed("FanSpeed",(uint32_t)fan_speed_val);
}

void MainWindow::on_airLevel3Btn_clicked()
{
    fan_speed_val = 191;
    LOG("Air Value: Level 3", ui->airLog);
    client_->Feed("FanSpeed",(uint32_t)fan_speed_val);
}

void MainWindow::on_airLevel4Btn_clicked()
{
    fan_speed_val = 255;
    LOG("Air Value: Level 4", ui->airLog);
    client_->Feed("FanSpeed",(uint32_t)fan_speed_val);
}

// Seat Control


void MainWindow::on_upSeatBtn_clicked()
{
    seat_position_val += 25;
    if (seat_position_val > 255)
        seat_position_val = 255;
    LOG("Seat Position: Up", ui->seatLog);
    client_->Feed("SeatPosition",(uint32_t)seat_position_val);
}

void MainWindow::on_downSeatBtn_clicked()
{
    if (seat_position_val >= 25)
        seat_position_val-=25;
    else
        seat_position_val = 0;
    LOG("Seat Position: Down", ui->seatLog);
    client_->Feed("SeatPosition",(uint32_t)seat_position_val);
}

void MainWindow::on_lockBtn_clicked()
{
    client_->Feed("DoorState",0);
}

void MainWindow::on_unlockBtn_clicked()
{
    client_->Feed("DoorState",1);
}



void MainWindow::on_lightUpBtn_clicked()
{
    light_state_val += 25;
    if (light_state_val > 255)
        light_state_val = 255;
    LOG("Brightness: Up", ui->lightLog);
    client_->Feed("LightState",(uint32_t)light_state_val);
}


void MainWindow::on_lightDownBtn_clicked()
{
    if (light_state_val >= 25)
        light_state_val-=25;
    else
        light_state_val = 0;
    LOG("Brightness: Down", ui->lightLog);
    client_->Feed("LightState",(uint32_t)light_state_val);
}
