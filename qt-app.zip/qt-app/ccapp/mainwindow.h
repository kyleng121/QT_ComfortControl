#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <thread>

#include <QMainWindow>
#include <QListWidget>
#include <QPropertyAnimation>
#include <gRPC_shared_lib/lib_grpc_jetson/vcu_logic_interface.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

enum class log_type
{
    airLog,
    seatLog,
    lightLog,
    statusLog
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:


    void on_homeBtn_2_toggled(bool checked);

    void on_lightBtn_2_toggled(bool checked);

    void on_seatBtn_2_toggled(bool checked);

    void on_airBtn_2_toggled(bool checked);

    void on_lightLevel_valueChanged(int value);

    void on_onLightBtn_clicked();

    void on_offLightBtn_clicked();

    void on_offAirBtn_clicked();

    void on_onAirBtn_clicked();

    void on_airLevel1Btn_clicked();

    void on_airLevel2Btn_clicked();

    void on_airLevel3Btn_clicked();

    void on_airLevel4Btn_clicked();

    void on_upSeatBtn_clicked();

    void on_downSeatBtn_clicked();

    void LOG(std::string content, QListWidget* logWidget);

    void on_lockBtn_clicked();

    void on_unlockBtn_clicked();

    void SpeedValueCallback(CallbackType callback_type, uint32_t value);
    void DoorStateCallback(CallbackType callback_type, uint32_t value);
    void LightStateCallback(CallbackType callback_type, uint32_t value);
    void FanSpeedCallback(CallbackType callback_type, uint32_t value);
    void SeatPositionCallback(CallbackType callback_type, uint32_t value);


    void on_lightUpBtn_clicked();

    void on_lightDownBtn_clicked();

private:
    Ui::MainWindow *ui;
    std::shared_ptr<VcuLogicHandlerInterface> client_;

    uint32_t seat_position_val;
    uint32_t fan_speed_val;
    uint32_t light_state_val;

    uint32_t readThreadRunning;
    uint32_t buttonState_current;
    uint32_t buttonState_previous;

    std::string ipc_txt_path;

};
#endif // MAINWINDOW_H
