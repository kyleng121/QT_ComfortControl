#ifndef VCU_LOGIC_INTERFACE_HPP
#define VCU_LOGIC_INTERFACE_HPP

#include <memory>
#include <functional>
#include <string>


enum class CallbackType
{
  kStatus = 0,
  kAcknowledge
};

using VcuCallbackFunctionType=std::function<void(CallbackType, uint32_t)>;

class VcuLogicHandlerInterface
{
public:
  ~VcuLogicHandlerInterface() = default;
  
  /*
  Currently available for feed:
    LightState
    SeatPosition
    FanSpeed
    DoorState
    VehicleSpeedLim
    DoorSpeedLim
  */
  virtual void Feed(std::string actuator, uint32_t value) = 0;

  /*
  Currently available for subscribe:
    LightState
    SeatPosition
    FanSpeed
    DoorState
    VehicleSpeedLim
    DoorSpeedLim
    VehicleSpeed
  */
  virtual void Subscribe(std::string actuator, VcuCallbackFunctionType) = 0;

};

class Builder
{
public:
  std::shared_ptr<VcuLogicHandlerInterface> GetLogicHandler();
};

#endif // VCU_LOGIC_INTERFACE_HPP