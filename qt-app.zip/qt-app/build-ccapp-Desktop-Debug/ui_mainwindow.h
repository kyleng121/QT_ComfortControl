/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_4;
    QWidget *menuBar;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *menuIcon;
    QLabel *appName;
    QVBoxLayout *verticalLayout;
    QPushButton *homeBtn_2;
    QPushButton *lightBtn_2;
    QPushButton *seatBtn_2;
    QPushButton *airBtn_2;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *verticalSpacer_4;
    QPushButton *pushButton_10;
    QWidget *mainWindow;
    QStackedWidget *stackedWidget;
    QWidget *homePage;
    QWidget *homePageHeader;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_4;
    QWidget *lightPageBody_2;
    QGridLayout *gridLayout_5;
    QWidget *lightControlArea_2;
    QVBoxLayout *verticalLayout_10;
    QSpacerItem *verticalSpacer_9;
    QFrame *lightBtnArea_2;
    QHBoxLayout *horizontalLayout_18;
    QPushButton *lockBtn;
    QSpacerItem *horizontalSpacer_19;
    QPushButton *unlockBtn;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_20;
    QSpacerItem *horizontalSpacer_24;
    QLabel *label_10;
    QSpacerItem *horizontalSpacer_25;
    QLabel *door_state;
    QSpacerItem *verticalSpacer_10;
    QWidget *lightContent_2;
    QFormLayout *formLayout_4;
    QWidget *widget_5;
    QVBoxLayout *verticalLayout_14;
    QHBoxLayout *horizontalLayout_21;
    QSpacerItem *horizontalSpacer_26;
    QLabel *label_11;
    QSpacerItem *horizontalSpacer_27;
    QLCDNumber *speed_value;
    QWidget *seatPage;
    QWidget *seatPageHeader;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_8;
    QWidget *seatPageBody;
    QGridLayout *gridLayout_3;
    QWidget *seatControlArea;
    QVBoxLayout *verticalLayout_9;
    QSpacerItem *verticalSpacer_7;
    QFrame *seatBtnArea;
    QHBoxLayout *horizontalLayout_15;
    QPushButton *upSeatBtn;
    QSpacerItem *spaceer;
    QPushButton *downSeatBtn;
    QFrame *frame_6;
    QWidget *widget;
    QVBoxLayout *verticalLayout_12;
    QSpacerItem *verticalSpacer_12;
    QHBoxLayout *horizontalLayout_16;
    QSpacerItem *horizontalSpacer_20;
    QLabel *label_9;
    QSpacerItem *horizontalSpacer_21;
    QSpacerItem *verticalSpacer_11;
    QSpacerItem *verticalSpacer_8;
    QWidget *seatContent;
    QFormLayout *formLayout_3;
    QWidget *widget_6;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_17;
    QSpacerItem *horizontalSpacer_22;
    QLabel *seatLogLabel;
    QSpacerItem *horizontalSpacer_23;
    QListWidget *seatLog;
    QWidget *airPage;
    QWidget *airPageHeader;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QWidget *airPageBody;
    QGridLayout *gridLayout_4;
    QWidget *airControlArea;
    QFormLayout *formLayout_5;
    QSpacerItem *verticalSpacer_5;
    QFrame *airBtnArea;
    QHBoxLayout *horizontalLayout_10;
    QPushButton *onAirBtn;
    QSpacerItem *horizontalSpacer_14;
    QPushButton *offAirBtn;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_15;
    QLabel *label_7;
    QSpacerItem *horizontalSpacer_16;
    QFrame *frame_5;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *airLevel1Btn;
    QPushButton *airLevel2Btn;
    QHBoxLayout *horizontalLayout_14;
    QPushButton *airLevel3Btn;
    QPushButton *airLevel4Btn;
    QSpacerItem *verticalSpacer_6;
    QWidget *airContent;
    QVBoxLayout *verticalLayout_8;
    QWidget *widget_4;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_12;
    QSpacerItem *horizontalSpacer_17;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_18;
    QListWidget *airLog;
    QWidget *lightPage;
    QWidget *lgihtPageHeader;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer_6;
    QWidget *lightPageBody;
    QGridLayout *gridLayout_2;
    QWidget *lightControlArea;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *verticalSpacer;
    QFrame *lightBtnArea;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *onLightBtn;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *offLightBtn;
    QFrame *frame;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_10;
    QLabel *label_5;
    QSpacerItem *horizontalSpacer_11;
    QHBoxLayout *horizontalLayout_19;
    QPushButton *lightUpBtn;
    QSpacerItem *horizontalSpacer_28;
    QPushButton *lightDownBtn;
    QSpacerItem *verticalSpacer_3;
    QWidget *lightContent;
    QFormLayout *formLayout;
    QWidget *widget_3;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_12;
    QLabel *label_6;
    QSpacerItem *horizontalSpacer_13;
    QListWidget *lightLog;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1920, 1200);
        MainWindow->setMaximumSize(QSize(1920, 1200));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setMaximumSize(QSize(1920, 1200));
        horizontalLayout_4 = new QHBoxLayout(centralwidget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        menuBar = new QWidget(centralwidget);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setMinimumSize(QSize(500, 1200));
        menuBar->setMaximumSize(QSize(500, 1200));
        gridLayout = new QGridLayout(menuBar);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        menuIcon = new QLabel(menuBar);
        menuIcon->setObjectName(QString::fromUtf8("menuIcon"));
        menuIcon->setMinimumSize(QSize(70, 70));
        menuIcon->setMaximumSize(QSize(100, 100));
        menuIcon->setPixmap(QPixmap(QString::fromUtf8(":/resource/resource/icon/autonomous-car.png")));
        menuIcon->setScaledContents(true);

        horizontalLayout->addWidget(menuIcon);

        appName = new QLabel(menuBar);
        appName->setObjectName(QString::fromUtf8("appName"));
        appName->setMinimumSize(QSize(300, 100));
        appName->setMaximumSize(QSize(400, 100));
        QFont font;
        font.setPointSize(24);
        appName->setFont(font);

        horizontalLayout->addWidget(appName);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        homeBtn_2 = new QPushButton(menuBar);
        homeBtn_2->setObjectName(QString::fromUtf8("homeBtn_2"));
        homeBtn_2->setMinimumSize(QSize(420, 80));
        homeBtn_2->setMaximumSize(QSize(400, 80));
        QFont font1;
        font1.setPointSize(20);
        homeBtn_2->setFont(font1);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/resource/resource/icon/home.png"), QSize(), QIcon::Normal, QIcon::Off);
        homeBtn_2->setIcon(icon);
        homeBtn_2->setIconSize(QSize(60, 60));
        homeBtn_2->setCheckable(true);
        homeBtn_2->setAutoExclusive(true);

        verticalLayout->addWidget(homeBtn_2);

        lightBtn_2 = new QPushButton(menuBar);
        lightBtn_2->setObjectName(QString::fromUtf8("lightBtn_2"));
        lightBtn_2->setMinimumSize(QSize(420, 80));
        lightBtn_2->setMaximumSize(QSize(400, 80));
        lightBtn_2->setFont(font1);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/resource/resource/icon/light.png"), QSize(), QIcon::Normal, QIcon::Off);
        lightBtn_2->setIcon(icon1);
        lightBtn_2->setIconSize(QSize(60, 60));
        lightBtn_2->setCheckable(true);
        lightBtn_2->setAutoExclusive(true);

        verticalLayout->addWidget(lightBtn_2);

        seatBtn_2 = new QPushButton(menuBar);
        seatBtn_2->setObjectName(QString::fromUtf8("seatBtn_2"));
        seatBtn_2->setMinimumSize(QSize(420, 80));
        seatBtn_2->setMaximumSize(QSize(420, 80));
        seatBtn_2->setFont(font1);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/resource/resource/icon/car-seat.png"), QSize(), QIcon::Normal, QIcon::Off);
        seatBtn_2->setIcon(icon2);
        seatBtn_2->setIconSize(QSize(60, 60));
        seatBtn_2->setCheckable(true);
        seatBtn_2->setAutoExclusive(true);

        verticalLayout->addWidget(seatBtn_2);

        airBtn_2 = new QPushButton(menuBar);
        airBtn_2->setObjectName(QString::fromUtf8("airBtn_2"));
        airBtn_2->setMinimumSize(QSize(420, 80));
        airBtn_2->setMaximumSize(QSize(420, 80));
        airBtn_2->setFont(font1);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/resource/resource/icon/fan.png"), QSize(), QIcon::Normal, QIcon::Off);
        airBtn_2->setIcon(icon3);
        airBtn_2->setIconSize(QSize(60, 60));
        airBtn_2->setCheckable(true);
        airBtn_2->setAutoExclusive(true);

        verticalLayout->addWidget(airBtn_2);


        gridLayout->addLayout(verticalLayout, 1, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 295, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 4, 0, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 335, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_4, 2, 0, 1, 1);

        pushButton_10 = new QPushButton(menuBar);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setMinimumSize(QSize(420, 80));
        pushButton_10->setMaximumSize(QSize(420, 80));
        pushButton_10->setFont(font1);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/resource/resource/icon/exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_10->setIcon(icon4);
        pushButton_10->setIconSize(QSize(60, 60));
        pushButton_10->setCheckable(true);
        pushButton_10->setAutoExclusive(true);

        gridLayout->addWidget(pushButton_10, 3, 0, 1, 1);


        horizontalLayout_4->addWidget(menuBar);

        mainWindow = new QWidget(centralwidget);
        mainWindow->setObjectName(QString::fromUtf8("mainWindow"));
        mainWindow->setMinimumSize(QSize(1520, 1200));
        mainWindow->setMaximumSize(QSize(1520, 1200));
        stackedWidget = new QStackedWidget(mainWindow);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 0, 1520, 1200));
        stackedWidget->setMinimumSize(QSize(1520, 1200));
        stackedWidget->setMaximumSize(QSize(1520, 1200));
        homePage = new QWidget();
        homePage->setObjectName(QString::fromUtf8("homePage"));
        homePage->setMinimumSize(QSize(1520, 1200));
        homePage->setMaximumSize(QSize(1520, 1200));
        homePageHeader = new QWidget(homePage);
        homePageHeader->setObjectName(QString::fromUtf8("homePageHeader"));
        homePageHeader->setGeometry(QRect(0, 0, 1520, 60));
        homePageHeader->setMinimumSize(QSize(1520, 60));
        homePageHeader->setMaximumSize(QSize(1520, 60));
        horizontalLayout_2 = new QHBoxLayout(homePageHeader);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(747, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        label_2 = new QLabel(homePageHeader);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(250, 40));
        label_2->setMaximumSize(QSize(90, 40));
        QFont font2;
        font2.setPointSize(24);
        font2.setBold(true);
        font2.setWeight(75);
        label_2->setFont(font2);

        horizontalLayout_2->addWidget(label_2);

        horizontalSpacer_4 = new QSpacerItem(557, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        lightPageBody_2 = new QWidget(homePage);
        lightPageBody_2->setObjectName(QString::fromUtf8("lightPageBody_2"));
        lightPageBody_2->setGeometry(QRect(0, 60, 1520, 1140));
        lightPageBody_2->setMinimumSize(QSize(1520, 1140));
        lightPageBody_2->setMaximumSize(QSize(1520, 1140));
        gridLayout_5 = new QGridLayout(lightPageBody_2);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        lightControlArea_2 = new QWidget(lightPageBody_2);
        lightControlArea_2->setObjectName(QString::fromUtf8("lightControlArea_2"));
        lightControlArea_2->setMinimumSize(QSize(320, 1140));
        lightControlArea_2->setMaximumSize(QSize(290, 1140));
        verticalLayout_10 = new QVBoxLayout(lightControlArea_2);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalSpacer_9 = new QSpacerItem(20, 180, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_9);

        lightBtnArea_2 = new QFrame(lightControlArea_2);
        lightBtnArea_2->setObjectName(QString::fromUtf8("lightBtnArea_2"));
        lightBtnArea_2->setMinimumSize(QSize(290, 160));
        lightBtnArea_2->setMaximumSize(QSize(290, 160));
        lightBtnArea_2->setFrameShape(QFrame::StyledPanel);
        lightBtnArea_2->setFrameShadow(QFrame::Raised);
        horizontalLayout_18 = new QHBoxLayout(lightBtnArea_2);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        lockBtn = new QPushButton(lightBtnArea_2);
        lockBtn->setObjectName(QString::fromUtf8("lockBtn"));
        lockBtn->setMinimumSize(QSize(120, 80));
        lockBtn->setMaximumSize(QSize(120, 80));
        QFont font3;
        font3.setPointSize(12);
        lockBtn->setFont(font3);
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/resource/resource/icon/lock.png"), QSize(), QIcon::Normal, QIcon::Off);
        lockBtn->setIcon(icon5);
        lockBtn->setIconSize(QSize(40, 40));
        lockBtn->setCheckable(false);
        lockBtn->setAutoExclusive(false);

        horizontalLayout_18->addWidget(lockBtn);

        horizontalSpacer_19 = new QSpacerItem(15, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_19);

        unlockBtn = new QPushButton(lightBtnArea_2);
        unlockBtn->setObjectName(QString::fromUtf8("unlockBtn"));
        unlockBtn->setMinimumSize(QSize(120, 80));
        unlockBtn->setMaximumSize(QSize(120, 80));
        unlockBtn->setFont(font3);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/resource/resource/icon/unlock.png"), QSize(), QIcon::Normal, QIcon::Off);
        unlockBtn->setIcon(icon6);
        unlockBtn->setIconSize(QSize(40, 40));
        unlockBtn->setCheckable(false);
        unlockBtn->setAutoExclusive(false);

        horizontalLayout_18->addWidget(unlockBtn);


        verticalLayout_10->addWidget(lightBtnArea_2);

        frame_2 = new QFrame(lightControlArea_2);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setMinimumSize(QSize(290, 100));
        frame_2->setMaximumSize(QSize(290, 100));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(frame_2);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        horizontalSpacer_24 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_24);

        label_10 = new QLabel(frame_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setMinimumSize(QSize(120, 35));
        label_10->setMaximumSize(QSize(120, 35));
        QFont font4;
        font4.setPointSize(18);
        label_10->setFont(font4);

        horizontalLayout_20->addWidget(label_10);

        horizontalSpacer_25 = new QSpacerItem(78, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_25);


        verticalLayout_13->addLayout(horizontalLayout_20);

        door_state = new QLabel(frame_2);
        door_state->setObjectName(QString::fromUtf8("door_state"));
        door_state->setFont(font1);
        door_state->setStyleSheet(QString::fromUtf8("door_state{\n"
"	background-color: #fff;\n"
"}"));

        verticalLayout_13->addWidget(door_state);


        verticalLayout_10->addWidget(frame_2);

        verticalSpacer_10 = new QSpacerItem(20, 658, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_10);


        gridLayout_5->addWidget(lightControlArea_2, 0, 0, 1, 1);

        lightContent_2 = new QWidget(lightPageBody_2);
        lightContent_2->setObjectName(QString::fromUtf8("lightContent_2"));
        lightContent_2->setMinimumSize(QSize(1230, 1140));
        lightContent_2->setMaximumSize(QSize(1230, 1140));
        formLayout_4 = new QFormLayout(lightContent_2);
        formLayout_4->setObjectName(QString::fromUtf8("formLayout_4"));
        widget_5 = new QWidget(lightContent_2);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        widget_5->setMinimumSize(QSize(700, 800));
        widget_5->setMaximumSize(QSize(700, 800));
        verticalLayout_14 = new QVBoxLayout(widget_5);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        horizontalSpacer_26 = new QSpacerItem(78, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_26);

        label_11 = new QLabel(widget_5);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMinimumSize(QSize(0, 40));
        label_11->setFont(font1);

        horizontalLayout_21->addWidget(label_11);

        horizontalSpacer_27 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_27);


        verticalLayout_14->addLayout(horizontalLayout_21);

        speed_value = new QLCDNumber(widget_5);
        speed_value->setObjectName(QString::fromUtf8("speed_value"));
        speed_value->setMinimumSize(QSize(700, 800));
        speed_value->setMaximumSize(QSize(16777215, 1520));
        speed_value->setSmallDecimalPoint(false);
        speed_value->setDigitCount(5);
        speed_value->setProperty("intValue", QVariant(0));

        verticalLayout_14->addWidget(speed_value);


        formLayout_4->setWidget(0, QFormLayout::LabelRole, widget_5);


        gridLayout_5->addWidget(lightContent_2, 0, 1, 1, 1);

        stackedWidget->addWidget(homePage);
        seatPage = new QWidget();
        seatPage->setObjectName(QString::fromUtf8("seatPage"));
        seatPage->setMinimumSize(QSize(1520, 1000));
        seatPage->setMaximumSize(QSize(1520, 1000));
        seatPageHeader = new QWidget(seatPage);
        seatPageHeader->setObjectName(QString::fromUtf8("seatPageHeader"));
        seatPageHeader->setGeometry(QRect(0, 0, 1520, 60));
        seatPageHeader->setMinimumSize(QSize(1520, 60));
        seatPageHeader->setMaximumSize(QSize(1520, 60));
        horizontalLayout_6 = new QHBoxLayout(seatPageHeader);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_7 = new QSpacerItem(747, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_7);

        label_4 = new QLabel(seatPageHeader);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(210, 40));
        label_4->setMaximumSize(QSize(210, 40));
        label_4->setFont(font2);

        horizontalLayout_6->addWidget(label_4);

        horizontalSpacer_8 = new QSpacerItem(557, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_8);

        seatPageBody = new QWidget(seatPage);
        seatPageBody->setObjectName(QString::fromUtf8("seatPageBody"));
        seatPageBody->setGeometry(QRect(0, 60, 1080, 1000));
        seatPageBody->setMinimumSize(QSize(1080, 1000));
        seatPageBody->setMaximumSize(QSize(1080, 1000));
        gridLayout_3 = new QGridLayout(seatPageBody);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        seatControlArea = new QWidget(seatPageBody);
        seatControlArea->setObjectName(QString::fromUtf8("seatControlArea"));
        seatControlArea->setMinimumSize(QSize(320, 1140));
        seatControlArea->setMaximumSize(QSize(290, 1140));
        verticalLayout_9 = new QVBoxLayout(seatControlArea);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalSpacer_7 = new QSpacerItem(20, 180, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_7);

        seatBtnArea = new QFrame(seatControlArea);
        seatBtnArea->setObjectName(QString::fromUtf8("seatBtnArea"));
        seatBtnArea->setMinimumSize(QSize(290, 160));
        seatBtnArea->setMaximumSize(QSize(290, 160));
        seatBtnArea->setFrameShape(QFrame::StyledPanel);
        seatBtnArea->setFrameShadow(QFrame::Raised);
        horizontalLayout_15 = new QHBoxLayout(seatBtnArea);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        upSeatBtn = new QPushButton(seatBtnArea);
        upSeatBtn->setObjectName(QString::fromUtf8("upSeatBtn"));
        upSeatBtn->setMinimumSize(QSize(120, 80));
        upSeatBtn->setMaximumSize(QSize(120, 80));
        upSeatBtn->setFont(font3);
        upSeatBtn->setIconSize(QSize(40, 40));
        upSeatBtn->setCheckable(false);
        upSeatBtn->setAutoExclusive(false);

        horizontalLayout_15->addWidget(upSeatBtn);

        spaceer = new QSpacerItem(15, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(spaceer);

        downSeatBtn = new QPushButton(seatBtnArea);
        downSeatBtn->setObjectName(QString::fromUtf8("downSeatBtn"));
        downSeatBtn->setMinimumSize(QSize(120, 80));
        downSeatBtn->setMaximumSize(QSize(120, 80));
        downSeatBtn->setFont(font3);
        downSeatBtn->setIconSize(QSize(40, 40));
        downSeatBtn->setCheckable(false);
        downSeatBtn->setAutoExclusive(false);

        horizontalLayout_15->addWidget(downSeatBtn);


        verticalLayout_9->addWidget(seatBtnArea);

        frame_6 = new QFrame(seatControlArea);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        frame_6->setMinimumSize(QSize(290, 150));
        frame_6->setMaximumSize(QSize(290, 100));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        widget = new QWidget(frame_6);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 0, 262, 131));
        verticalLayout_12 = new QVBoxLayout(widget);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_12->addItem(verticalSpacer_12);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        horizontalSpacer_20 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_20);

        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setMinimumSize(QSize(140, 35));
        label_9->setMaximumSize(QSize(140, 35));
        label_9->setFont(font4);

        horizontalLayout_16->addWidget(label_9);

        horizontalSpacer_21 = new QSpacerItem(38, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_21);


        verticalLayout_12->addLayout(horizontalLayout_16);

        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_12->addItem(verticalSpacer_11);


        verticalLayout_9->addWidget(frame_6);

        verticalSpacer_8 = new QSpacerItem(20, 658, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_8);


        gridLayout_3->addWidget(seatControlArea, 0, 0, 1, 1);

        seatContent = new QWidget(seatPageBody);
        seatContent->setObjectName(QString::fromUtf8("seatContent"));
        seatContent->setMinimumSize(QSize(1080, 1000));
        seatContent->setMaximumSize(QSize(1230, 1000));
        formLayout_3 = new QFormLayout(seatContent);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        widget_6 = new QWidget(seatContent);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        widget_6->setMinimumSize(QSize(700, 800));
        widget_6->setMaximumSize(QSize(700, 800));
        verticalLayout_11 = new QVBoxLayout(widget_6);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalSpacer_22 = new QSpacerItem(78, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_22);

        seatLogLabel = new QLabel(widget_6);
        seatLogLabel->setObjectName(QString::fromUtf8("seatLogLabel"));
        seatLogLabel->setMinimumSize(QSize(0, 40));
        seatLogLabel->setMaximumSize(QSize(16777215, 16777215));
        seatLogLabel->setFont(font1);

        horizontalLayout_17->addWidget(seatLogLabel);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_23);


        verticalLayout_11->addLayout(horizontalLayout_17);

        seatLog = new QListWidget(widget_6);
        seatLog->setObjectName(QString::fromUtf8("seatLog"));
        seatLog->setMaximumSize(QSize(680, 800));
        QFont font5;
        font5.setPointSize(25);
        seatLog->setFont(font5);

        verticalLayout_11->addWidget(seatLog);


        formLayout_3->setWidget(0, QFormLayout::LabelRole, widget_6);


        gridLayout_3->addWidget(seatContent, 0, 1, 1, 1);

        stackedWidget->addWidget(seatPage);
        airPage = new QWidget();
        airPage->setObjectName(QString::fromUtf8("airPage"));
        airPage->setMinimumSize(QSize(1520, 1200));
        airPage->setMaximumSize(QSize(1520, 1200));
        airPageHeader = new QWidget(airPage);
        airPageHeader->setObjectName(QString::fromUtf8("airPageHeader"));
        airPageHeader->setGeometry(QRect(0, 0, 1520, 60));
        airPageHeader->setMinimumSize(QSize(1520, 60));
        airPageHeader->setMaximumSize(QSize(1520, 60));
        horizontalLayout_3 = new QHBoxLayout(airPageHeader);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(747, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        label = new QLabel(airPageHeader);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(180, 40));
        label->setMaximumSize(QSize(180, 40));
        label->setFont(font2);

        horizontalLayout_3->addWidget(label);

        horizontalSpacer_2 = new QSpacerItem(557, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        airPageBody = new QWidget(airPage);
        airPageBody->setObjectName(QString::fromUtf8("airPageBody"));
        airPageBody->setGeometry(QRect(0, 60, 1080, 1000));
        airPageBody->setMinimumSize(QSize(1080, 1000));
        airPageBody->setMaximumSize(QSize(700, 1000));
        gridLayout_4 = new QGridLayout(airPageBody);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        airControlArea = new QWidget(airPageBody);
        airControlArea->setObjectName(QString::fromUtf8("airControlArea"));
        airControlArea->setMinimumSize(QSize(320, 1140));
        airControlArea->setMaximumSize(QSize(290, 1140));
        formLayout_5 = new QFormLayout(airControlArea);
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        verticalSpacer_5 = new QSpacerItem(20, 180, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout_5->setItem(0, QFormLayout::LabelRole, verticalSpacer_5);

        airBtnArea = new QFrame(airControlArea);
        airBtnArea->setObjectName(QString::fromUtf8("airBtnArea"));
        airBtnArea->setMinimumSize(QSize(290, 160));
        airBtnArea->setMaximumSize(QSize(290, 160));
        airBtnArea->setFrameShape(QFrame::StyledPanel);
        airBtnArea->setFrameShadow(QFrame::Raised);
        horizontalLayout_10 = new QHBoxLayout(airBtnArea);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        onAirBtn = new QPushButton(airBtnArea);
        onAirBtn->setObjectName(QString::fromUtf8("onAirBtn"));
        onAirBtn->setMinimumSize(QSize(120, 80));
        onAirBtn->setMaximumSize(QSize(120, 80));
        onAirBtn->setFont(font3);
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/resource/resource/icon/power.png"), QSize(), QIcon::Normal, QIcon::Off);
        onAirBtn->setIcon(icon7);
        onAirBtn->setIconSize(QSize(40, 40));
        onAirBtn->setCheckable(false);
        onAirBtn->setAutoExclusive(false);

        horizontalLayout_10->addWidget(onAirBtn);

        horizontalSpacer_14 = new QSpacerItem(15, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_14);

        offAirBtn = new QPushButton(airBtnArea);
        offAirBtn->setObjectName(QString::fromUtf8("offAirBtn"));
        offAirBtn->setMinimumSize(QSize(120, 80));
        offAirBtn->setMaximumSize(QSize(120, 80));
        offAirBtn->setFont(font3);
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/resource/resource/icon/power-off.png"), QSize(), QIcon::Normal, QIcon::Off);
        offAirBtn->setIcon(icon8);
        offAirBtn->setIconSize(QSize(40, 40));
        offAirBtn->setCheckable(false);
        offAirBtn->setAutoExclusive(false);

        horizontalLayout_10->addWidget(offAirBtn);


        formLayout_5->setWidget(1, QFormLayout::LabelRole, airBtnArea);

        frame_3 = new QFrame(airControlArea);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setMinimumSize(QSize(290, 150));
        frame_3->setMaximumSize(QSize(290, 100));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        verticalLayout_6 = new QVBoxLayout(frame_3);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalSpacer_15 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_15);

        label_7 = new QLabel(frame_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setMinimumSize(QSize(110, 35));
        label_7->setMaximumSize(QSize(110, 35));
        label_7->setFont(font4);

        horizontalLayout_11->addWidget(label_7);

        horizontalSpacer_16 = new QSpacerItem(78, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_16);


        verticalLayout_6->addLayout(horizontalLayout_11);


        formLayout_5->setWidget(2, QFormLayout::LabelRole, frame_3);

        frame_5 = new QFrame(airControlArea);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setMinimumSize(QSize(290, 120));
        frame_5->setMaximumSize(QSize(290, 120));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(frame_5);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        airLevel1Btn = new QPushButton(frame_5);
        airLevel1Btn->setObjectName(QString::fromUtf8("airLevel1Btn"));
        airLevel1Btn->setMinimumSize(QSize(100, 40));
        airLevel1Btn->setMaximumSize(QSize(100, 40));
        airLevel1Btn->setCheckable(false);
        airLevel1Btn->setAutoExclusive(false);

        horizontalLayout_13->addWidget(airLevel1Btn);

        airLevel2Btn = new QPushButton(frame_5);
        airLevel2Btn->setObjectName(QString::fromUtf8("airLevel2Btn"));
        airLevel2Btn->setMinimumSize(QSize(100, 40));
        airLevel2Btn->setMaximumSize(QSize(100, 40));
        airLevel2Btn->setCheckable(false);
        airLevel2Btn->setAutoExclusive(false);

        horizontalLayout_13->addWidget(airLevel2Btn);


        verticalLayout_5->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        airLevel3Btn = new QPushButton(frame_5);
        airLevel3Btn->setObjectName(QString::fromUtf8("airLevel3Btn"));
        airLevel3Btn->setMinimumSize(QSize(100, 40));
        airLevel3Btn->setMaximumSize(QSize(100, 40));
        airLevel3Btn->setCheckable(false);
        airLevel3Btn->setAutoExclusive(false);

        horizontalLayout_14->addWidget(airLevel3Btn);

        airLevel4Btn = new QPushButton(frame_5);
        airLevel4Btn->setObjectName(QString::fromUtf8("airLevel4Btn"));
        airLevel4Btn->setMinimumSize(QSize(100, 40));
        airLevel4Btn->setMaximumSize(QSize(100, 40));
        airLevel4Btn->setCheckable(false);
        airLevel4Btn->setAutoExclusive(false);

        horizontalLayout_14->addWidget(airLevel4Btn);


        verticalLayout_5->addLayout(horizontalLayout_14);


        formLayout_5->setWidget(3, QFormLayout::LabelRole, frame_5);

        verticalSpacer_6 = new QSpacerItem(20, 658, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout_5->setItem(4, QFormLayout::LabelRole, verticalSpacer_6);


        gridLayout_4->addWidget(airControlArea, 0, 0, 1, 1);

        airContent = new QWidget(airPageBody);
        airContent->setObjectName(QString::fromUtf8("airContent"));
        airContent->setMinimumSize(QSize(700, 1000));
        airContent->setMaximumSize(QSize(1230, 1000));
        verticalLayout_8 = new QVBoxLayout(airContent);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        widget_4 = new QWidget(airContent);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        widget_4->setMinimumSize(QSize(700, 800));
        widget_4->setMaximumSize(QSize(700, 800));
        verticalLayout_7 = new QVBoxLayout(widget_4);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalSpacer_17 = new QSpacerItem(78, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_17);

        label_8 = new QLabel(widget_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setMinimumSize(QSize(0, 40));
        label_8->setFont(font1);

        horizontalLayout_12->addWidget(label_8);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_18);


        verticalLayout_7->addLayout(horizontalLayout_12);

        airLog = new QListWidget(widget_4);
        airLog->setObjectName(QString::fromUtf8("airLog"));
        airLog->setMaximumSize(QSize(680, 800));
        airLog->setFont(font5);

        verticalLayout_7->addWidget(airLog);


        verticalLayout_8->addWidget(widget_4);


        gridLayout_4->addWidget(airContent, 0, 1, 1, 1);

        stackedWidget->addWidget(airPage);
        lightPage = new QWidget();
        lightPage->setObjectName(QString::fromUtf8("lightPage"));
        lightPage->setMinimumSize(QSize(1520, 1200));
        lightPage->setMaximumSize(QSize(1520, 1200));
        lgihtPageHeader = new QWidget(lightPage);
        lgihtPageHeader->setObjectName(QString::fromUtf8("lgihtPageHeader"));
        lgihtPageHeader->setGeometry(QRect(0, 0, 1520, 60));
        lgihtPageHeader->setMinimumSize(QSize(1520, 60));
        lgihtPageHeader->setMaximumSize(QSize(1520, 60));
        horizontalLayout_5 = new QHBoxLayout(lgihtPageHeader);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_5 = new QSpacerItem(747, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_5);

        label_3 = new QLabel(lgihtPageHeader);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(210, 40));
        label_3->setMaximumSize(QSize(210, 40));
        label_3->setFont(font2);

        horizontalLayout_5->addWidget(label_3);

        horizontalSpacer_6 = new QSpacerItem(557, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_6);

        lightPageBody = new QWidget(lightPage);
        lightPageBody->setObjectName(QString::fromUtf8("lightPageBody"));
        lightPageBody->setGeometry(QRect(0, 60, 1520, 1140));
        lightPageBody->setMinimumSize(QSize(1520, 1140));
        lightPageBody->setMaximumSize(QSize(1520, 1140));
        gridLayout_2 = new QGridLayout(lightPageBody);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        lightControlArea = new QWidget(lightPageBody);
        lightControlArea->setObjectName(QString::fromUtf8("lightControlArea"));
        lightControlArea->setMinimumSize(QSize(320, 1140));
        lightControlArea->setMaximumSize(QSize(290, 1140));
        verticalLayout_4 = new QVBoxLayout(lightControlArea);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalSpacer = new QSpacerItem(20, 180, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer);

        lightBtnArea = new QFrame(lightControlArea);
        lightBtnArea->setObjectName(QString::fromUtf8("lightBtnArea"));
        lightBtnArea->setMinimumSize(QSize(290, 160));
        lightBtnArea->setMaximumSize(QSize(290, 160));
        lightBtnArea->setFrameShape(QFrame::StyledPanel);
        lightBtnArea->setFrameShadow(QFrame::Raised);
        horizontalLayout_7 = new QHBoxLayout(lightBtnArea);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        onLightBtn = new QPushButton(lightBtnArea);
        onLightBtn->setObjectName(QString::fromUtf8("onLightBtn"));
        onLightBtn->setMinimumSize(QSize(120, 80));
        onLightBtn->setMaximumSize(QSize(120, 80));
        onLightBtn->setFont(font3);
        onLightBtn->setIcon(icon7);
        onLightBtn->setIconSize(QSize(40, 40));
        onLightBtn->setCheckable(false);
        onLightBtn->setAutoExclusive(false);

        horizontalLayout_7->addWidget(onLightBtn);

        horizontalSpacer_9 = new QSpacerItem(15, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_9);

        offLightBtn = new QPushButton(lightBtnArea);
        offLightBtn->setObjectName(QString::fromUtf8("offLightBtn"));
        offLightBtn->setMinimumSize(QSize(120, 80));
        offLightBtn->setMaximumSize(QSize(120, 80));
        offLightBtn->setFont(font3);
        offLightBtn->setIcon(icon8);
        offLightBtn->setIconSize(QSize(40, 40));
        offLightBtn->setCheckable(false);
        offLightBtn->setAutoExclusive(false);

        horizontalLayout_7->addWidget(offLightBtn);


        verticalLayout_4->addWidget(lightBtnArea);

        frame = new QFrame(lightControlArea);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(290, 150));
        frame->setMaximumSize(QSize(290, 100));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(frame);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalSpacer_10 = new QSpacerItem(60, 28, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_10);

        label_5 = new QLabel(frame);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMinimumSize(QSize(120, 35));
        label_5->setMaximumSize(QSize(120, 35));
        label_5->setFont(font4);

        horizontalLayout_8->addWidget(label_5);

        horizontalSpacer_11 = new QSpacerItem(70, 28, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_11);


        verticalLayout_2->addLayout(horizontalLayout_8);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        lightUpBtn = new QPushButton(frame);
        lightUpBtn->setObjectName(QString::fromUtf8("lightUpBtn"));
        lightUpBtn->setMinimumSize(QSize(90, 50));
        lightUpBtn->setMaximumSize(QSize(90, 50));

        horizontalLayout_19->addWidget(lightUpBtn);

        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_28);

        lightDownBtn = new QPushButton(frame);
        lightDownBtn->setObjectName(QString::fromUtf8("lightDownBtn"));
        lightDownBtn->setMinimumSize(QSize(90, 50));
        lightDownBtn->setMaximumSize(QSize(90, 50));

        horizontalLayout_19->addWidget(lightDownBtn);


        verticalLayout_2->addLayout(horizontalLayout_19);


        verticalLayout_4->addWidget(frame);

        verticalSpacer_3 = new QSpacerItem(20, 658, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_3);


        gridLayout_2->addWidget(lightControlArea, 0, 0, 1, 1);

        lightContent = new QWidget(lightPageBody);
        lightContent->setObjectName(QString::fromUtf8("lightContent"));
        lightContent->setMinimumSize(QSize(1230, 1140));
        lightContent->setMaximumSize(QSize(1230, 1140));
        formLayout = new QFormLayout(lightContent);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        widget_3 = new QWidget(lightContent);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setMinimumSize(QSize(700, 800));
        widget_3->setMaximumSize(QSize(700, 800));
        verticalLayout_3 = new QVBoxLayout(widget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalSpacer_12 = new QSpacerItem(78, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_12);

        label_6 = new QLabel(widget_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMinimumSize(QSize(0, 40));
        label_6->setFont(font1);

        horizontalLayout_9->addWidget(label_6);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_13);


        verticalLayout_3->addLayout(horizontalLayout_9);

        lightLog = new QListWidget(widget_3);
        lightLog->setObjectName(QString::fromUtf8("lightLog"));
        lightLog->setMaximumSize(QSize(680, 800));
        lightLog->setFont(font5);

        verticalLayout_3->addWidget(lightLog);


        formLayout->setWidget(0, QFormLayout::LabelRole, widget_3);


        gridLayout_2->addWidget(lightContent, 0, 1, 1, 1);

        stackedWidget->addWidget(lightPage);

        horizontalLayout_4->addWidget(mainWindow);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);
        QObject::connect(pushButton_10, SIGNAL(toggled(bool)), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        menuIcon->setText(QString());
        appName->setText(QApplication::translate("MainWindow", "Comfort Control App", nullptr));
        homeBtn_2->setText(QApplication::translate("MainWindow", "Monitoring", nullptr));
        lightBtn_2->setText(QApplication::translate("MainWindow", "Light Control", nullptr));
        seatBtn_2->setText(QApplication::translate("MainWindow", "Seat Control", nullptr));
        airBtn_2->setText(QApplication::translate("MainWindow", "Air Control", nullptr));
        pushButton_10->setText(QApplication::translate("MainWindow", "Exit", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Speed and Door", nullptr));
        lockBtn->setText(QApplication::translate("MainWindow", "Lock", nullptr));
        unlockBtn->setText(QApplication::translate("MainWindow", "Unlock", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "Door State", nullptr));
        door_state->setText(QString());
        label_11->setText(QApplication::translate("MainWindow", "Speed", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Seat Settings", nullptr));
        upSeatBtn->setText(QApplication::translate("MainWindow", "Up", nullptr));
        downSeatBtn->setText(QApplication::translate("MainWindow", "Down", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "Seat Position", nullptr));
        seatLogLabel->setText(QApplication::translate("MainWindow", "Seat Log", nullptr));
        label->setText(QApplication::translate("MainWindow", "Air Settings", nullptr));
        onAirBtn->setText(QApplication::translate("MainWindow", "Air On", nullptr));
        offAirBtn->setText(QApplication::translate("MainWindow", "Air Off", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Air Speed", nullptr));
        airLevel1Btn->setText(QApplication::translate("MainWindow", "Level 1", nullptr));
        airLevel2Btn->setText(QApplication::translate("MainWindow", "Level 2", nullptr));
        airLevel3Btn->setText(QApplication::translate("MainWindow", "Level 3", nullptr));
        airLevel4Btn->setText(QApplication::translate("MainWindow", "Level 4", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "Air Log", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Light Settings", nullptr));
        onLightBtn->setText(QApplication::translate("MainWindow", "Light On", nullptr));
        offLightBtn->setText(QApplication::translate("MainWindow", "Light Off", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Brightness", nullptr));
        lightUpBtn->setText(QApplication::translate("MainWindow", "Up", nullptr));
        lightDownBtn->setText(QApplication::translate("MainWindow", "Down", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "Light Log", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
