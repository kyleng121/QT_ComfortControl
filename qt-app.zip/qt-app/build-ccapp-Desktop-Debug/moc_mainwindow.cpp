/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../ccapp/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[36];
    char stringdata0[626];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 20), // "on_homeBtn_2_toggled"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 7), // "checked"
QT_MOC_LITERAL(4, 41, 21), // "on_lightBtn_2_toggled"
QT_MOC_LITERAL(5, 63, 20), // "on_seatBtn_2_toggled"
QT_MOC_LITERAL(6, 84, 19), // "on_airBtn_2_toggled"
QT_MOC_LITERAL(7, 104, 26), // "on_lightLevel_valueChanged"
QT_MOC_LITERAL(8, 131, 5), // "value"
QT_MOC_LITERAL(9, 137, 21), // "on_onLightBtn_clicked"
QT_MOC_LITERAL(10, 159, 22), // "on_offLightBtn_clicked"
QT_MOC_LITERAL(11, 182, 20), // "on_offAirBtn_clicked"
QT_MOC_LITERAL(12, 203, 19), // "on_onAirBtn_clicked"
QT_MOC_LITERAL(13, 223, 23), // "on_airLevel1Btn_clicked"
QT_MOC_LITERAL(14, 247, 23), // "on_airLevel2Btn_clicked"
QT_MOC_LITERAL(15, 271, 23), // "on_airLevel3Btn_clicked"
QT_MOC_LITERAL(16, 295, 23), // "on_airLevel4Btn_clicked"
QT_MOC_LITERAL(17, 319, 20), // "on_upSeatBtn_clicked"
QT_MOC_LITERAL(18, 340, 22), // "on_downSeatBtn_clicked"
QT_MOC_LITERAL(19, 363, 3), // "LOG"
QT_MOC_LITERAL(20, 367, 11), // "std::string"
QT_MOC_LITERAL(21, 379, 7), // "content"
QT_MOC_LITERAL(22, 387, 12), // "QListWidget*"
QT_MOC_LITERAL(23, 400, 9), // "logWidget"
QT_MOC_LITERAL(24, 410, 18), // "on_lockBtn_clicked"
QT_MOC_LITERAL(25, 429, 20), // "on_unlockBtn_clicked"
QT_MOC_LITERAL(26, 450, 18), // "SpeedValueCallback"
QT_MOC_LITERAL(27, 469, 12), // "CallbackType"
QT_MOC_LITERAL(28, 482, 13), // "callback_type"
QT_MOC_LITERAL(29, 496, 8), // "uint32_t"
QT_MOC_LITERAL(30, 505, 17), // "DoorStateCallback"
QT_MOC_LITERAL(31, 523, 18), // "LightStateCallback"
QT_MOC_LITERAL(32, 542, 16), // "FanSpeedCallback"
QT_MOC_LITERAL(33, 559, 20), // "SeatPositionCallback"
QT_MOC_LITERAL(34, 580, 21), // "on_lightUpBtn_clicked"
QT_MOC_LITERAL(35, 602, 23) // "on_lightDownBtn_clicked"

    },
    "MainWindow\0on_homeBtn_2_toggled\0\0"
    "checked\0on_lightBtn_2_toggled\0"
    "on_seatBtn_2_toggled\0on_airBtn_2_toggled\0"
    "on_lightLevel_valueChanged\0value\0"
    "on_onLightBtn_clicked\0on_offLightBtn_clicked\0"
    "on_offAirBtn_clicked\0on_onAirBtn_clicked\0"
    "on_airLevel1Btn_clicked\0on_airLevel2Btn_clicked\0"
    "on_airLevel3Btn_clicked\0on_airLevel4Btn_clicked\0"
    "on_upSeatBtn_clicked\0on_downSeatBtn_clicked\0"
    "LOG\0std::string\0content\0QListWidget*\0"
    "logWidget\0on_lockBtn_clicked\0"
    "on_unlockBtn_clicked\0SpeedValueCallback\0"
    "CallbackType\0callback_type\0uint32_t\0"
    "DoorStateCallback\0LightStateCallback\0"
    "FanSpeedCallback\0SeatPositionCallback\0"
    "on_lightUpBtn_clicked\0on_lightDownBtn_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  139,    2, 0x08 /* Private */,
       4,    1,  142,    2, 0x08 /* Private */,
       5,    1,  145,    2, 0x08 /* Private */,
       6,    1,  148,    2, 0x08 /* Private */,
       7,    1,  151,    2, 0x08 /* Private */,
       9,    0,  154,    2, 0x08 /* Private */,
      10,    0,  155,    2, 0x08 /* Private */,
      11,    0,  156,    2, 0x08 /* Private */,
      12,    0,  157,    2, 0x08 /* Private */,
      13,    0,  158,    2, 0x08 /* Private */,
      14,    0,  159,    2, 0x08 /* Private */,
      15,    0,  160,    2, 0x08 /* Private */,
      16,    0,  161,    2, 0x08 /* Private */,
      17,    0,  162,    2, 0x08 /* Private */,
      18,    0,  163,    2, 0x08 /* Private */,
      19,    2,  164,    2, 0x08 /* Private */,
      24,    0,  169,    2, 0x08 /* Private */,
      25,    0,  170,    2, 0x08 /* Private */,
      26,    2,  171,    2, 0x08 /* Private */,
      30,    2,  176,    2, 0x08 /* Private */,
      31,    2,  181,    2, 0x08 /* Private */,
      32,    2,  186,    2, 0x08 /* Private */,
      33,    2,  191,    2, 0x08 /* Private */,
      34,    0,  196,    2, 0x08 /* Private */,
      35,    0,  197,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 22,   21,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 27, 0x80000000 | 29,   28,    8,
    QMetaType::Void, 0x80000000 | 27, 0x80000000 | 29,   28,    8,
    QMetaType::Void, 0x80000000 | 27, 0x80000000 | 29,   28,    8,
    QMetaType::Void, 0x80000000 | 27, 0x80000000 | 29,   28,    8,
    QMetaType::Void, 0x80000000 | 27, 0x80000000 | 29,   28,    8,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_homeBtn_2_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->on_lightBtn_2_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->on_seatBtn_2_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->on_airBtn_2_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_lightLevel_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_onLightBtn_clicked(); break;
        case 6: _t->on_offLightBtn_clicked(); break;
        case 7: _t->on_offAirBtn_clicked(); break;
        case 8: _t->on_onAirBtn_clicked(); break;
        case 9: _t->on_airLevel1Btn_clicked(); break;
        case 10: _t->on_airLevel2Btn_clicked(); break;
        case 11: _t->on_airLevel3Btn_clicked(); break;
        case 12: _t->on_airLevel4Btn_clicked(); break;
        case 13: _t->on_upSeatBtn_clicked(); break;
        case 14: _t->on_downSeatBtn_clicked(); break;
        case 15: _t->LOG((*reinterpret_cast< std::string(*)>(_a[1])),(*reinterpret_cast< QListWidget*(*)>(_a[2]))); break;
        case 16: _t->on_lockBtn_clicked(); break;
        case 17: _t->on_unlockBtn_clicked(); break;
        case 18: _t->SpeedValueCallback((*reinterpret_cast< CallbackType(*)>(_a[1])),(*reinterpret_cast< uint32_t(*)>(_a[2]))); break;
        case 19: _t->DoorStateCallback((*reinterpret_cast< CallbackType(*)>(_a[1])),(*reinterpret_cast< uint32_t(*)>(_a[2]))); break;
        case 20: _t->LightStateCallback((*reinterpret_cast< CallbackType(*)>(_a[1])),(*reinterpret_cast< uint32_t(*)>(_a[2]))); break;
        case 21: _t->FanSpeedCallback((*reinterpret_cast< CallbackType(*)>(_a[1])),(*reinterpret_cast< uint32_t(*)>(_a[2]))); break;
        case 22: _t->SeatPositionCallback((*reinterpret_cast< CallbackType(*)>(_a[1])),(*reinterpret_cast< uint32_t(*)>(_a[2]))); break;
        case 23: _t->on_lightUpBtn_clicked(); break;
        case 24: _t->on_lightDownBtn_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QListWidget* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
